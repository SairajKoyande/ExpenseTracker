package com.example.expensetracker;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class SummaryActivity extends AppCompatActivity {

    private TextView tvSummaryTotal;
    private ListView lvSummaryExpenses;
    private ArrayList<Expense> expenseList;
    private ArrayAdapter<String> expenseAdapter;
    private ArrayList<String> expenseDisplayList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_summary);

        tvSummaryTotal = findViewById(R.id.tvSummaryTotal);
        lvSummaryExpenses = findViewById(R.id.lvSummaryExpenses);

        expenseList = new ArrayList<>();
        expenseDisplayList = new ArrayList<>();
        expenseAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, expenseDisplayList);
        lvSummaryExpenses.setAdapter(expenseAdapter);

        loadExpenses();
        displaySummary();
    }

    private void loadExpenses() {
        SharedPreferences sharedPreferences = getSharedPreferences("expenses", MODE_PRIVATE);
        Gson gson = new Gson();
        String json = sharedPreferences.getString("expenseList", null);
        Type type = new TypeToken<ArrayList<Expense>>() {}.getType();
        expenseList = gson.fromJson(json, type);

        if (expenseList == null) {
            expenseList = new ArrayList<>();
        }
    }

    private void displaySummary() {
        double total = 0;
        String currentMonth = new SimpleDateFormat("MMMM", Locale.getDefault()).format(new Date());
        SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss", Locale.getDefault());

        expenseDisplayList.clear();
        for (Expense expense : expenseList) {
            total += expense.getAmount();
            expenseDisplayList.add(expense.getName() + " - ₹" + expense.getAmount() + " (" + expense.getCategory() + ")\n" +
                    expense.getDescription() + "\n" + sdf.format(expense.getDateTime()));
        }
        expenseAdapter.notifyDataSetChanged();
        tvSummaryTotal.setText("Total for " + currentMonth + ": ₹" + total);
    }
}
