package com.example.expensetracker;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.SearchView;
import android.widget.Spinner;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    private EditText etExpenseName, etExpenseAmount, etExpenseDescription;
    private Spinner spinnerCategory;
    private Button btnAddExpense, btnShowSummary, btnLogout;
    private ListView lvExpenses;
    private SearchView searchView;
    private ArrayList<Expense> expenseList;
    private ArrayAdapter<String> expenseAdapter;
    private ArrayList<String> expenseDisplayList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etExpenseName = findViewById(R.id.etExpenseName);
        etExpenseAmount = findViewById(R.id.etExpenseAmount);
        etExpenseDescription = findViewById(R.id.etExpenseDescription);
        spinnerCategory = findViewById(R.id.spinnerCategory);
        btnAddExpense = findViewById(R.id.btnAddExpense);
        btnShowSummary = findViewById(R.id.btnShowSummary);
        btnLogout = findViewById(R.id.btnLogout);
        lvExpenses = findViewById(R.id.lvExpenses);
        searchView = findViewById(R.id.searchView);

        expenseList = new ArrayList<>();
        expenseDisplayList = new ArrayList<>();
        expenseAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, expenseDisplayList);
        lvExpenses.setAdapter(expenseAdapter);

        btnAddExpense.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addExpense();
            }
        });

        btnShowSummary.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, SummaryActivity.class);
                startActivity(intent);
            }
        });

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                searchExpenses(newText);
                return true;
            }
        });

        btnLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                logout();
            }
        });

        loadExpenses();
        updateExpenseListDisplay();
    }

    private void addExpense() {
        String name = etExpenseName.getText().toString();
        String amountStr = etExpenseAmount.getText().toString();
        String description = etExpenseDescription.getText().toString();
        String category = spinnerCategory.getSelectedItem().toString();
        Date dateTime = new Date();

        if (name.isEmpty() || amountStr.isEmpty() || description.isEmpty()) {
            Toast.makeText(this, "Please enter all details", Toast.LENGTH_SHORT).show();
            return;
        }

        double amount;
        try {
            amount = Double.parseDouble(amountStr);
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Invalid amount format", Toast.LENGTH_SHORT).show();
            return;
        }

        Expense expense = new Expense(name, amount, category, description, dateTime);
        expenseList.add(expense);
        saveExpenses();
        updateExpenseListDisplay();

        Toast.makeText(this, "Expense added", Toast.LENGTH_SHORT).show();

        // Clear inputs
        etExpenseName.setText("");
        etExpenseAmount.setText("");
        etExpenseDescription.setText("");
    }

    private void saveExpenses() {
        SharedPreferences sharedPreferences = getSharedPreferences("expenses", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        Gson gson = new Gson();
        String json = gson.toJson(expenseList);
        editor.putString("expenseList", json);
        editor.apply();
    }

    private void loadExpenses() {
        SharedPreferences sharedPreferences = getSharedPreferences("expenses", MODE_PRIVATE);
        Gson gson = new Gson();
        String json = sharedPreferences.getString("expenseList", null);
        Type type = new TypeToken<ArrayList<Expense>>() {}.getType();
        expenseList = gson.fromJson(json, type);

        if (expenseList == null) {
            expenseList = new ArrayList<>();
        }
    }

    private void updateExpenseListDisplay() {
        expenseDisplayList.clear();
        SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss", Locale.getDefault());
        for (Expense expense : expenseList) {
            expenseDisplayList.add(expense.getName() + " - ₹" + expense.getAmount() + " (" + expense.getCategory() + ")\n" +
                    expense.getDescription() + "\n" + sdf.format(expense.getDateTime()));
        }
        expenseAdapter.notifyDataSetChanged();
    }

    private void searchExpenses(String query) {
        ArrayList<String> filteredList = new ArrayList<>();
        SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss", Locale.getDefault());
        for (Expense expense : expenseList) {
            if (expense.getName().toLowerCase().contains(query.toLowerCase()) ||
                    expense.getCategory().toLowerCase().contains(query.toLowerCase()) ||
                    expense.getDescription().toLowerCase().contains(query.toLowerCase())) {
                filteredList.add(expense.getName() + " - ₹" + expense.getAmount() + " (" + expense.getCategory() + ")\n" +
                        expense.getDescription() + "\n" + sdf.format(expense.getDateTime()));
            }
        }
        expenseAdapter.clear();
        expenseAdapter.addAll(filteredList);
        expenseAdapter.notifyDataSetChanged();
    }

    private void logout() {
        SharedPreferences preferences = getSharedPreferences("user_prefs", MODE_PRIVATE);
        SharedPreferences.Editor editor = preferences.edit();
        editor.putBoolean("isLoggedIn", false);
        editor.apply();

        Intent intent = new Intent(MainActivity.this, SignInActivity.class);
        startActivity(intent);
        finish();
    }
}
